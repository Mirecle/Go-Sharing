package testdata

var gl int

type X struct {
	a int
	b int
}

func main() {
	print(gl)
}
