// This package is great // want `package comment should be of the form`
package pkg
